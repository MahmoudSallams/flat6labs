<?php

namespace Ideas\Shop\Controllers;

class Weight extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_weight'];
    public $controllerName = 'weight';
}
