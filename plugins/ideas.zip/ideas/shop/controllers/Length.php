<?php

namespace Ideas\Shop\Controllers;

class Length extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_length'];
    public $controllerName = 'length';
}
