<?php

namespace Ideas\Shop\Controllers;

class Reason extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_reason'];
    public $controllerName = 'reason';
}
