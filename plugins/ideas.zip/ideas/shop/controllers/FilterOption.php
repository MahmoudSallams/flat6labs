<?php

namespace Ideas\Shop\Controllers;

class FilterOption extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_filter_option'];
    public $controllerName = 'filteroption';
}
