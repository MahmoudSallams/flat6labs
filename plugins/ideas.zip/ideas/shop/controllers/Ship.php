<?php

namespace Ideas\Shop\Controllers;

class Ship extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_ship'];
    public $controllerName = 'ship';

}
