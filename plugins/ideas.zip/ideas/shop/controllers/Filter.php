<?php

namespace Ideas\Shop\Controllers;

class Filter extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_filter'];
    public $controllerName = 'filter';
}
