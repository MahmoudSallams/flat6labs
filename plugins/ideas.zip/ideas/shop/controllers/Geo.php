<?php

namespace Ideas\Shop\Controllers;

class Geo extends IdeasShopController
{
    public $requiredPermissions = ['ideas.shop.access_geo'];
    public $controllerName = 'geo';
}
