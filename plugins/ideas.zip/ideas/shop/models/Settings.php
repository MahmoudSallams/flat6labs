<?php

namespace Ideas\Shop\Models;

use October\Rain\Database\Model;

class Settings extends Model
{
}