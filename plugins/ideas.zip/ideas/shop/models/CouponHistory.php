<?php namespace Ideas\Shop\Models;

use October\Rain\Database\Model;

class CouponHistory extends Model
{
    protected $table = 'ideas_coupon_history';
}