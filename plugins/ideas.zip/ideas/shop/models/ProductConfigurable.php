<?php

namespace Ideas\Shop\Models;

use October\Rain\Database\Model;

class ProductConfigurable extends Model
{
    protected $table = 'ideas_product_configurable';
    public $timestamps = false;//disable 'created_at' and 'updated_at'


}